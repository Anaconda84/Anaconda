# -*- coding: utf-8 -*-
# Create your views here.
from django.shortcuts import render_to_response
from django.http import HttpResponse
from VideoApp.models import VideoBaza
from VideoApp.utils import *
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

#import os

def video(request):
    list = VideoBaza.objects.all()
    paginator = Paginator(list, 10) # Show 10 contacts per page
    
    page = request.GET.get('page')
    try:
        list = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        list = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        list = paginator.page(paginator.num_pages)    
    return render_to_response('base.html', {'list':list})

def video_category(request, category):
    cat ={}
    cat[1] = u'Авторское кино'
    cat[2] = u'Аниме'
    cat[3] = u'Артхаус'
    cat[4] = u'Биографические'
    cat[5] = u'Боевики'
    cat[6] = u'Военные'
    cat[7] = u'Детективы'
    cat[8] = u'Драмы'
    cat[9] = u'Исторические'
    cat[10] = u'Комедии'
    cat[11] = u'Криминальные'
    cat[12] = u'Мелодрамы'
    cat[13] = u'Мультфильмы'
    cat[14] = u'Отечественные'
    cat[15] = u'Приключения'
    cat[16] = u'Семейные'
    cat[17] = u'Триллеры'
    cat[18] = u'Ужасы'
    cat[19] = u'Фантастика'
    cat[20] = u'Фентези'


    list = VideoBaza.objects.filter(janr=cat[int(category)])
    paginator = Paginator(list, 10) # Show 10 contacts per page
    
    page = request.GET.get('page')
    try:
        list = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        list = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        list = paginator.page(paginator.num_pages)    
    return render_to_response('base.html', {'list':list})


def version(request):
    return HttpResponse("0.8")

def seeders(request, torrent):
    resp = get_seeders(request, torrent)
    out = ''
    i = 0
    for ip in resp:
      if i == 0:
          out = ip
      else:
          out = out+','+ip
      i = i + 1

    return HttpResponse(out)

def notsupport(request):
    return render_to_response('notsupport.html')

def about(request):
    return render_to_response('about.html')
                                                        