<?php

$b = pack("c", 0x9f);
//$a=0x9f;
echo $b;
//echo chr('\x9f');





?>