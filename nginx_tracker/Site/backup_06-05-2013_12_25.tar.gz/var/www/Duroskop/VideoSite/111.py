import os

print os.path.join(os.path.abspath(os.path.dirname(__file__)), 'VideoSite', 'static')

