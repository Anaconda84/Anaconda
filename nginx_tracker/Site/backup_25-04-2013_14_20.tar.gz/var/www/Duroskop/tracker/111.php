<?php 
echo "1111";
$db = sqlite_open("db/tracker.db") or 
die("failed to open/create the database"); 
echo "2222";
?>