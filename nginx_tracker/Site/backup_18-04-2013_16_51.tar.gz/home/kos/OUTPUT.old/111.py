import codecs

out = codecs.open('output1.log', 'w', 'utf-8')
for line in codecs.open('output.log', encoding='utf-8'):
  mas = line.split("|")
  img = mas[10].split("/")
  print img[2]
  str=mas[0]+'|'+mas[1]+'|'+mas[2]+'|'+mas[3]+'|'+mas[4]+'|'+mas[5]+'|'+mas[6]+'|'+mas[7]+'|'+mas[8]+'|'+mas[9]+'|'+img[2]+'|'+mas[11]+'|'+mas[12]
  out.write(str)
out.close()
        